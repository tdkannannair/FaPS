
App.Dispatcher.on("uploadpic", function() {         
    $(":file").change(function() {
        if (this.files && this.files[0] && this.files[0].name.match(/\.(jpg|jpeg|png|gif)$/) ) {
            if(this.files[0].size>1048576) {
                alert('File size is larger than 1MB!');
            }
            else {
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
            }
        } else alert('This is not an image file!');
    });
    function imageIsLoaded(e) {
        result = e.target.result;
        $('#image').attr('src', result);
    };
});
 
