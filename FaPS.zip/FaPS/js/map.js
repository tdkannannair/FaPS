 $(document).ready(function() {

  navigator.geolocation.getCurrentPosition(initialise);

  function initialise(position) {

    coords = position.coords;
    $("#lat_field").val(coords.latitude);
    $("#long_field").val(coords.longitude);
    lat = coords.latitude;
    long = coords.longitude;

  };
});

function initMap() {
  var newCont = "<div><b>You Are Here!</b></div>";
  infowindow = new google.maps.InfoWindow({
    content: newCont,
  });
  navigator.geolocation.getCurrentPosition(function(position) {
    var pos = {

      lat: position.coords.latitude,
      lng: position.coords.longitude
    };

    map = new google.maps.Map(document.getElementById('map'), {
      center: pos,
      zoom: 15

    });
    
    var marker = new google.maps.Marker({
      position: pos,
      animation: google.maps.Animation.DROP,
      map: map,
      title: 'You Are Here!'
    });

    marker.addListener('click', function() {
      infowindow.open(map, marker);
    });

    var request = {
      location: pos,
      radius: '500',
      types: ['cafe']
    };
      $('.radius').append("<b>Places to eat within " + request.radius + " meters</b>");
    var service = new google.maps.places.PlacesService(map);
    service.nearbySearch(request, callback);

    function callback(results, status) {
      if (status == google.maps.places.PlacesServiceStatus.OK) {
        for (var i = 0; i < results.length; i++) {
          var place = results[i];
          createMarker(results[i]);
          console.log(results[i]); 
         $('.listPlaces').append('<li>'+place.name+'</li>');
        }
      }
    }

    function createMarker(place) {
      
      var iconBase = new google.maps.MarkerImage( place.icon, null, null, null, new                       google.maps.Size(30, 30)); 
      //var newImage = "http://weknowyourdreams.com/images/dog/dog-07.jpg";
          
          ;
      var placeLoc = place.geometry.location;
      var nearbyMarker = new google.maps.Marker({
        map: map,
        icon: iconBase ,
        position: placeLoc
      });
      
      google.maps.event.addListener(nearbyMarker, 'click', function() {
        infowindow.setContent(place.name);
        infowindow.open(map, this);
      });
    }

  });
}