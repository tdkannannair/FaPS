<?php
$con=mysqli_connect("localhost","root","","faps") or die('unable to connect');
//echo "ok db connected";
/*
if(!$con)
echo "not sucess";
else
echo "$con";*/
?>
