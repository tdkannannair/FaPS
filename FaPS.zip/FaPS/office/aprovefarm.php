<?php
	include("../dbconnect.php");
	$id=$_POST['email'];
	
	$query="update login set status='1' where email='$id'"; 
	$query_exe=mysqli_query($con,$query);
 ?>