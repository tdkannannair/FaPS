<!DOCTYPE HTML>
<html lang="en-US">
<head>
<?php
 session_start();
 include 'dbconnect.php';
 $eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){
?>
	<meta name='revisit-after' content='1 days' />
	<title>Faps | feedback</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" href="css/feed.css">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color3.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/img.css" media="all"/>
	
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
	<?php include 'header.php'?>
	<!-- End Header -->
		 
		 
	<section id="content">
		<div class="container">
		 
			<!-- End Content Top -->
			 
			<!-- End List Service -->
	 
	 
			<!-- End Product Type -->
 
			<!-- End Product Best Sale -->
			 
			 
			<!-- End Latest News -->
			<div class="list-product-type4">
				<div class="row">
				 
 
				</div>
			</div>
			<!-- End Product Type -->
		 
			<!-- End Service -->
	 
	 
		 
	 
	<!-- End Wishlist Mask -->
	 
	</div>
	<!-- End Preload -->
</div>

<!-- modals
-->   <h2 class="title30 font-bold title-box1 text-uppercase text-center"> message admin</h2>
		 <P style="color:BLUE;" ALIGN=CENTER >  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp PLESE GIVE VALID FEEDBACK TO US A WE CAN IMPROVE USER EXPERIENCE</P>
				<div class="product-loadmore">
					<div class="row">
					<form action="add_msg.php" method="post">
      <p class="name">
        <input name="subject" type="text" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" placeholder="SUBJECT" id="name" />
      </p>
      
       
      
      <p class="text">
        <textarea name="text" class="validate[required,length[6,300]] feedback-input" id="comment" placeholder="DISCRIPTION"></textarea>
      </p>
      
      
      <div class="submit">
        <input type="submit" value="SEND" id="button-blue"/>
		<div class="ease"></div>
		</form>
							</div>
						</div>
<!-- ----------------------------------->


	 
      
  

				 
			</div>
		</div>
	</section>
	<!-- End Content -->
	<footer id="footer">
		<div class="footer3">
			<div class="footer-top3">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc">Phone 8848182799</p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3">For better experience give your valuable feed back through messages <a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			</div>
			<!-- End Footer Top -->
			 
					<!-- End List Brand -->
				 
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->
	 
	 
	<!-- End Preload -->
 
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/img2.js"></script>
 <script type="text/javascript" src="js/image.js"></script> 
	
<script>
	
	$(function(){

	
		$('body').on("click", ".tdktitto", function(event){
			var t=this;
			var tdk1 = $(t).attr("tdk");
			$.ajax({
						type: "POST",
						url: "delete.php",
						data: {id:tdk1},
						success: function(result){
							alert("APROVED......!");
						$(".tdktitto"+tdk1).fadeOut("slow"); 
							 
							
						
						}
				});
			 
		});	 
			 
	 
		 
		
		
	}); 
	 
</script>
</body>
</html>
<?php
 
}
else
{
    header("location:../login.php");
}

?>