<?php
 
	 
	$subject=$_POST['subject'];
	$text=$_POST['text'];
	$sender=1011;
    $query="INSERT INTO feedback (detail, discription,sender) VALUES ('$subject','$text','$sender')"; 
	$query_exe=mysqli_query($con,$query);
	header("location:shopkeeper.php");
 ?>
  