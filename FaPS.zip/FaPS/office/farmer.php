<?php
 session_start();
include 'dbconnect.php';
$eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){
	 ?>
 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="description" content="Fruit Shop is new Html theme that we have designed to help you transform your store into a beautiful online showroom. This is a fully responsive Html theme, with multiple versions for homepage and multiple templates for sub pages as well" />
	<meta name="keywords" content="Fruit,7uptheme" />
	<meta name="robots" content="noodp,index,follow" />
	<meta name='revisit-after' content='1 days' />
	<title>Faps | office</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color3.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/img.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/w3.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
	<?php include 'header.php'?>
	<!-- End Header -->
			<div class="container">
			<div class="statistic-box">
				 <h2 class="title30 font-bold text-center border-bottom">DATA</h2>
		 		<div id="page-wrapper">
			 <!-- <div class="list-service3 bg-color2">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="#" class="color2"> <p>84</p></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="#" class="white">Total request </a></h3>
								<p class="desc white"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="#" class="color2"> <p>12</p></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="#" class="white">Aproved</a></h3>
								<p class="desc white"> 
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="#" class="color2"> <p>72</p></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="#" class="white">Rejected</a></h3>
								<p class="desc white"> </p>
							</div>
						</div>
					</div>
				</div>
		 
			</div> -->
			<!-- data -->
			<div class="container">
			<?php
		 $sql = "SELECT * FROM login JOIN registeration ON login.email = registeration.email JOIN farm ON farm.email = registeration.email where login.status=0 ORDER BY id DESC";
				// $sql="SELECT * FROM login JOIN registeration ON login.email = registeration.email JOIN docreg ON docreg.email = registeration.email where login.status=1";
				$result=mysqli_query($con,$sql);
				if (mysqli_num_rows($result) > 0) {
											?>
	     										
                                 
   
  <table class="table">
     
    <thead class=" ltr">
      
       <tr>
        <th>name</th> 
        <th>  contact</th>
        <th>address</th> 
		<th>photo</th>
      </tr>
    </thead>
    <tbody>
      <?php
	while($row = mysqli_fetch_assoc($result)) {
	 
		$pic=$row['pic'];
		$shop_certificate=$row['farm_certificate'];
		$ownership=$row['ownership'];
		echo$pic;
		echo$shop_certificate;
													?>
      <tr class="tdkkannan<?php echo $row['email'] ?>">
       <td><?php echo $row['name'] ?></td>
       <td><?php echo $row['contact'] ?></td>                                                                                                                                                           
	   
       <td><?php echo $row['adress'] ?></td>
        
        <td>
		<button class="button" id="toggle-modal" data-toggle="#thismodal">photos</button> 
		</td>
<!-- modal -->
<div class="modal" id="thismodal">
  		  <div class="modal-dialog modal-dialog-closed modal-fill">
      		  <div class="modal-content">
          		  <div class="modal-header">
						<button id="shoppic"> farm pic </button> <button  id="cert">certificate </button> <button  id="own">ownership </button>
			                <button type="button" class="close" data-dismiss="modal" data-remove="#thismodal">
                    <span aria-hidden="true">&times;</span>
					</button>
				<h4 id="art">shope picture</h4>
            </div>
            <div class="modal-body">
			<img id="myImage" class="img-responsive" src=" " style="height:500px; width:1100px;">	
		  
			    </div>
            <div class="modal-footer">
			 
			<?php echo "</td>";
			
			?>
			<script>
			     document.getElementById("toggle-modal").addEventListener("click", myFunction);
				document.getElementById("shoppic").addEventListener("click", myFunction);
				document.getElementById("cert").addEventListener("click", myFunction2);
				document.getElementById("own").addEventListener("click", myFunction3);

				function myFunction() {
					 var newTitle = "farm picture";
						document.getElementById('myImage').src= "../images/upload/<?php echo $pic;?>";
					$( "#art" ).text(newTitle)
				}
				function myFunction2() {
					var newTitle = "certificate";
					document.getElementById('myImage').src="../images/upload/<?php echo $shop_certificate;?>";
					$( "#art" ).text(newTitle)
				}
				function myFunction3() {
					var newTitle = "ownership";
					document.getElementById('myImage').src="../images/upload/<?php echo $ownership?>";
					$( "#art" ).text(newTitle)
				}
			</script>
 
 				</div>
            </div>
        </div>
    </div>
</div>
        <!-- modal end	  -->
       
		<td>
        
        
		<input type="image" name="delete" class="tdkkannan"  value="red" tdk="<?php echo $row['email'] ?>"  alt="red" src=" ../images/icon/aprov.jpg">
	</td>
        
      </tr>
       
       
    </tbody>
    <?php
												}
											} else {
												echo "0 results";
											}

										?>
										 
  </table>
			 </div>
			 <!-- end data -->
		
	<section id="content">
		<div class="container">
		  
 
			<!-- End Why Choise -->
		</div>
		<div class="newsletter-box bg-color">
			<div class="container">
				<ul class="inner-newsletter white list-inline-block">
					 
						<form class="email-form">
							 
						</form>
					</li>
				</ul>
			</div>
		</div>
	</section>
	<!-- End Content -->
	<footer id="footer">
		<div class="footer3">
			<div class="footer-top3">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc">Phone 8848182799</p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3">For better experience give your valuable feed back through messages <a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			</div>
			<!-- End Footer Top -->
			 
					<!-- End List Brand -->
				 
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->
	 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
 
</html>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/img2.js"></script>
 <script type="text/javascript" src="js/image.js"></script> 
</body>
</html>
<script>
	
	$(function(){

	
		$('body').on("click", ".tdkkannan", function(event){
			var t=this;
			var email = $(t).attr("tdk");
			var selector = ".tdkkannan"+email;
			$.ajax({
						type: "POST",
						url: "aprovefarm.php",
						data: {'email': email},
						success: function(result){
							alert("aproved......!");
							window.location.href="farmer.php";
							/* $('#loader').load(' #loader');*/ 
							
						
						}
				});
			 
		});	 
			 
	 
		
		 
		
		
		}); 
	 
</script>
 
</body>
<?php

}
else
{
    header("location:../login.php");
}

?>
</html>