 <?php
	include("dbconnect.php");
	session_start();
	$cat = $_POST['cat'];
	$subcat = $_POST['subcat']; 
    		$name = $_POST['name']; 
	        $quantity = $_POST['quantity']; 
			$price = $_POST['price']; 
			$date=date("y/m/d");
			$pic = $_FILES['pic']['name']; 
			$from = $_POST['from']; 
			$to = $_POST['to']; 
			$pic2 = $_FILES['pic2']['name']; 
			$pic3 = $_FILES['pic3']['name']; 
			$email=$_SESSION['email']; 
			 

			 $photo = rand(999,9999).$_FILES["pic"]["name"];
			 $photo2 = rand(999,9999).$_FILES["pic2"]["name"];
			 $photo3 = rand(999,9999).$_FILES["pic3"]["name"];



$folder = "../shopkeeper/images/";

			 move_uploaded_file($_FILES["pic"]["tmp_name"],$folder.$photo);
		move_uploaded_file($_FILES["pic2"]["tmp_name"],$folder.$photo2);
		move_uploaded_file($_FILES["pic3"]["tmp_name"],$folder.$photo3);

 
  
	$query="INSERT INTO `product`(`name`, `quantity`, `rate`, `pic`, `sales`, `date`, `edate`, `email`, `pic2`, `pic3`,`catagory`, `subcatagory`, `published`) VALUES ('$name','$quantity','$price','$photo','0','$from','$to','$email','$photo2','$photo3','$cat','$subcat','$date')";
 
	$query_exe=mysqli_query($con,$query);

	$sql4 = "SELECT * FROM `subcatagory` WHERE id='$subcat'";
	$result4=mysqli_query($con,$sql4);
	$row4= mysqli_fetch_assoc($result4);
	$sc=$row['subcat_name'];
	$noti=' the  product '.$name.'of type '.$sc.' was been added by the farmer'.$email;
    $sql = "SELECT * FROM login WHERE type='shopkeeper'";
	$result=mysqli_query($con,$sql);
	if (mysqli_num_rows($result) > 0) {
											 
		while($row = mysqli_fetch_assoc($result)) {
			$e=$row['email'];
			$query="INSERT INTO notification(content,date,sender,receiver,status,type) VALUES ('$noti','$date','farmer','$e','0','farmer')";
			$query_exe=mysqli_query($con,$query);
		 
			if($d == $catagory)
			{
				$A=1;
			}
		}
	}
	
	
	 
	 
	
	
	header("location:product.php");
?>
