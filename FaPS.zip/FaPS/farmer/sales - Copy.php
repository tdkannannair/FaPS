 <?php
 session_start();
include 'dbconnect.php';
	$sid =$_POST['sold'];
	$uid =$_POST['save'];
	$rate =$_POST['rate'];
	$date=date("y/m/d");

	  $sql = "SELECT * FROM product WHERE id='$sid'";
	  $result=mysqli_query($con,$sql);
	  $row = mysqli_fetch_assoc($result);
	  $email=$row['email'];
	  $quantity=$row['quantity'];
	  $erate=$row['rate'];
	   
	//  $result=mysqli_query($con,$sql);
	//  $row = mysqli_fetch_assoc($result);
	 
	// $sql="select * from login where email='$sid'";
	// 	$result=mysqli_query($con,$sql);
	 
	 
	
		$sql1="UPDATE product SET sales=1 WHERE id='$sid'";
		$sql2="INSERT INTO `sales`(`farm_id`, `p_id`, `date`, `shop_id`, `quantity`, `espect_rate`, `sold`) VALUES ('$email','$sid','$date','$uid','$quantity','$erate','$rate')";
	 
		
	$res=mysqli_query($con,$sql1);
	$res1=mysqli_query($con,$sql2);
 
	header("location:producTLIST.php");

	 
	 	
	
?>
