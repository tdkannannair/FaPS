<!DOCTYPE HTML>
<html lang="en-US">
<head>
<?php
 session_start();
 include 'dbconnect.php';
 $eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){
 


?>
<script src='https://api.mapbox.com/mapbox.js/v3.1.1/mapbox.js'></script>
<link href='https://api.mapbox.com/mapbox.js/v3.1.1/mapbox.css' rel='stylesheet' />

<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>

<script src="https://unpkg.com/frappe-charts@0.0.8/dist/frappe-charts.min.iife.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
<meta charset="utf-8"> 
	<title>Faps | Farmer</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color7.css" media="all"/> 
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/particle.css"/>
	<link rel="stylesheet" type="text/css" href="css/notification.css"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
								<li><a href="../tool/logout.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
							 
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
		<div class="main-header bg-color2,item head">;
				<div class="container,sub-grid">
				<div id="particles-js">
				<div class="name-container"><span class="name"> 
					 welcome  farmer  
			 	</span>
				</div>
				 
			</div>
		 
			<!-- End Main Header -->
			<div class="nav-header bg-white nav-header11 header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
							<li class="current-menu-item menu-item-has-children">
								<a href="farmer.php">Home</a>
								 
							</li>
							 
							<li><a href="add_product.php">add product</a></li>
							<li><a href="product.php">my products</a></li>
							<li><a href="producTLIST.php">bedates</a></li>
						</ul>
						<a href="#" class="toggle-mobile-menu"><span></span></a>
					</nav>
				 </div>
			</div>
			<!-- End Nav Header -->
		</div>
	</header>
	<!-- End Header -->
	<?php
include('../dbconnect.php');
$sql = "SELECT COUNT(id) AS n1 FROM product and email='$eml'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n1=$row['n1'];
$sql = "SELECT COUNT(id) AS n2 FROM  product WHERE sales = '1'and and email='$eml'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n2=$row['n2'];
$sql = "SELECT COUNT(id) AS n3 FROM  product WHERE sales = '0' and email='$eml'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n3=$row['n3'];
$sql = "SELECT COUNT(id) AS n4 FROM  notification WHERE receiver = '$eml' and status='0'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n4=$row['n4'];
 ?>
	<section id="content">
		<div class="container">
		 <br><br><br><br><br><br>
					<br>
			<!-- End Banner Slider -->
			<div class="shop-policy11">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">curent product</h2>
							<a href="#"><img src="images/home/home11/ad1.jpg" alt="" /><h2><?php echo $n3; ?></h2></a>
							<p class="desc"> </p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">sold</h2>
							<a href="#"><img src="images/home/home11/ad2.jpg" alt="" /><h2><?php echo $n2; ?></h2></a>
							<p class="desc"> </p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">total products</h2>
							<a href="#"><img src="images/home/home11/ad3.jpg" alt="" /><h2><?php echo $n1; ?></h2></a>
							<p class="desc"> </p>
						</div>
					</div>
				</div>
			</div>
			<!-- End Shop Policy -->
		</div>
		 
		<!-- End Product Box -->
		 
			<!-- End List Adv -->
		</div>
	 
		<?php if($n4 <= 0){
        
	}
	else{
		?>
	
	<a href="notification.php" class="float">
	<span class="bell fa fa-bell"></span>
</a>
<div class="label-container">
<div class="label-text"><?php echo $n4; ?> notifications</div>
<i class="fa fa-play label-arrow"></i>
</div>
<?php 
}
?>
									<!-- End Item -->
		<div class="item">
		<div class="item-product-type table">
					<Br><Br><Br><Br><Br><Br><Br><Br><Br>	 
			</div>
		</div>
		<!-- End Product Type -->
		<div class="newsletter-box text-center bg-color2">
			<div class="container">
				<ul class="inner-newsletter white list-inline-block">
					 
				</ul>
			</div>
		</div>
	</section>
	<!-- End Content -->
	<footer id="footer">
		 
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc"><h3>Phone 8848182799</h3></p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3"><h5>For better experience give your valuable feed back through messages </h5><a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			 
		 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/particles.min.js"></script>

<script type="text/javascript" src="js/particle.js"></script>
</body>
<?php

}
else
{
    header("location:../login.php");
}

?>
</html>