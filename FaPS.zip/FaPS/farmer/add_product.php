<?php
include('../dbconnect.php');
session_start();
  
 $eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){


?> 
<!DOCTYPE HTML>
 
<html lang="en-US">
<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
 
	<title>Add products</title>
<head>
<script>
	
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Meta tag Keywords -->`
	<!-- css file -->
	<link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css file -->
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Cuprum:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<!-- //web-fonts -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/modal.css">
  <script src="js/modal.js"></script>
  <script src="js/modal2.js"></script>
	 
	
	<link rel="stylesheet" type="text/css" href="css/PIC.css"/>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/add_product.css"/>
 
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color4.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/PIC.css"/>
	  <style>
		  .text-center {
  text-align : center;
}
	</style>
</head>
<body class="preload" style="background:#f4f4f4">

<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
							<li><a href="../tool/logout.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">
				 
			</div>
			<!-- End Main Header -->
			<div class="nav-header bg-white header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
						<li class="current-menu-item menu-item-has-children">
								<a href="farmer.php">Home</a>
								 
							</li>
							 
							<li><a href="add_product.php">add product</a></li>
							<li><a href="product.php">my products</a></li>
							<li><a href="producTLIST.php">Bid</a></li>
						</ul>
						<a href="#" class="toggle-mobile-menu"><span></span></a>
					</nav>
				</div>
			</div>
			<!-- End Nav Header -->
		</div>
	</header>
 
			 <div class="container">
			<!-- <div class="statistic-box">  -->
				<h2 class="title30 font-bold text-center border-bottom">ADD</h2>
 
				<form action='add_product_db.php' method="post" enctype="multipart/form-data">	
		<div class="col-md-3 col-sm-4 col-xs-6" id ="left">
        <br><br>
				<br>
        
</div>
 
				<!--  -->
							</div>
												
					<div class="row">
						<!-- left side -->
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div style=" margin-left:330px;">
								<label for="add-priority">catagory</label>
							 
								<select class="form-control" id="cat" name="cat" v-model="product.priority" onchange="getDistrict(this.value);">
								<option  value disabled selected>Select catagory</option>
					<?php

$res = mysqli_query($con,"select * from catagory");

while($row = mysqli_fetch_array($res))
{
?>
<option value="<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name']; ?></option>
<?php
}
?>
      						</select>
							</div>
						<div class="item-post1">
						<div class="form-group"style=" margin-left:330px;" >
          <label for="productName">Product name</label>
          <input type="text" NAME="name" class="form-control" id="productName" placeholder="e.g. Awesome sneakers"style=" display: block; border: 1px solid #ccc; border-radius: 4px;" required>
				</div>
				<div class="form-group"style=" margin-left:330px;">
					 
					 <label for="productPrice">Product price in INR per kg</label>
					 <input type="number" class="form-control" id="productPrice" name="price" placeholder="e.g. 130" required >  
					 <label for="productPrice">Product Quantity in kg</label>
					 <input type="number" class="form-control" id="productPrice" name="quantity" placeholder="e.g. 30" required > 
					 <label for="productPrice"><h5>Enter the date of experity </h5></label>
					 <label for="productPrice">From</label>
				 <input type="date" class="form-control mat-inputs" name="from" id="from"   onchange="DateCheck()" placeholder="expire date"   required>
				 <label for="productPrice">&nbsp To</label>
				 <input type="date" class="form-control mat-inputs" name="to"  id="to" onchange="DateCheck()" placeholder="expire date"    required> 
				 <div ><label style=" ">upload a third image </label>
							       <input type="file" id="" name="pic3" style="   background-color:#a5b6d3;" ><br>
						</div>
						</div>
					</div>
					</div>
					<!-- right side -->

					<div class="col-md-6 col-sm-6 col-xs-12">
					<div style=" margin-left:50px;margin-right: 250px;">
								<label for="add-priority">sub catagory</label>
      						<select class="form-control" id="sub_cat" name="subcat"v-model="product.priority"  >
									<option  value disabled selected>Select sub catagory</option>
					<?php

$res = mysqli_query($con,"select * from subcatagory");

while($row = mysqli_fetch_array($res))
{
?>
<option value="<?php echo $row['id']; ?>"><?php echo $row['subcat_name']; ?></option>
<?php
}
?>
      						</select>
					
							</div><br>
						<div class="item-post1">
						<label for="productName"style="margin-left:50px;">     main pic of the product</label>
						<label style="font-size:10px;color:red;">prefer to upload pics with 800 x 800 or greater </label><br>
						<div class="form-group"id="right" style=" margin-right: 550px;">
					<br>

						 
			  			 <canvas id = "div2"></canvas>
					<script src= "js/PIC2.js"></script>
						<p style="color:black;">
  							filename:
					<input type = "file" name="pic" multiple= "false" accept = "image/*" id = "finput2" onchange = "upload()" style="background-color:#a5b6d3;" required />

							</p>
							</div>
							<div ><label style="  margin-left:100px;">upload a second image </label>
							       <input type="file" id="" name="pic2" style="  margin-left:100px;margin-right: 250px;background-color:#a5b6d3;"required ><br>
						</div>
						<button id="btnAddOfficer"type="submit" class="btn btn-primary"style=" margin-left:100;margin-right: 850px;"> ADD</button> 
					</div>
					</div>
				</div>
				
         
      </form>
  
</div>
<!-- </div>  -->
 
   
 
 <div id="loader">
 
<div class="container1 justify-content-start ltr">
   
   <style>
	
	   .tdk tbody tr:hover{ background-color:#589223; cursor: pointer; color: #F3E2E2; }
	
	</style>
	
	
	
	
	
  
</div>                              
 </div>   
</div>

 

			</div>
	<section id="content">
		<div class="container">
		 
			<!-- End Content Top -->
			 
			<!-- End List Service -->
	 
	 
			<!-- End Product Type -->
 
			<!-- End Product Best Sale -->
			 
			 
			<!-- End Latest News -->
			<div class="list-product-type4">
				<div class="row">
				 
 
				</div>
			</div>
			<!-- End Product Type -->
		 
			<!-- End Service -->
	 
	 
	 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<?php

}
else
{
    header("location:../login.php");
}
?>
<script type="text/javascript"src="js/table1.js"></script>
<script type="text/javascript" src="js/table2.js"></script>
<script type="text/javascript" src="js/add.js"></script>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script src="../js/jquery-2.2.3.min.js"></script>
<script type="text/javascript"src="js/PIC2.js">	
	<script src="../js/jquery-simple-validator.min.js"></script>

 <script>
 function getDistrict(val) {
			 
		 

      $.ajax({
      type: "POST",
      url: "catagory_db.php",
      data: {cat_id:val},
      success: function(data){
        //alert(data);
        // document.write(data);
       $("#sub_cat").html(data);
      },error: function(data){
      //alert(data);
      }
      });
			}
 
       
       

	 
 
		
		// $("#btnAddOfficer").on("click",function(){
			//validation
			//ajax call
			// var name = $("#name").val();
			// var quantity = $("#quantity").val();
			// var price = $("#price").val();
			// var pic = $("#pic").val();
			 
			 	
			// var data=new FormData();
      //       data.append("name",name);
      //       data.append("quantity",quantity);
      //       data.append("price",price);
      //       data.append("pic",pic);
           		  
		// 	$.ajax({
		// 				type: "POST",
		// 				url: "add_product_db.php",
		// 				data: data,
		// 				processData: false,
    //                     contentType: false,
		// 				success: function(result){
		// 					alert("ADDED......!");
		// 					$('#loader').load('add_agre_officer.php #loader')
							 
		// 				$(".class").val('');						}
		// 		});
		// });
		
		
		// }); 
	 
</script>
<script>
                          function DateCheck()
                    {
                      var StartDate= document.getElementById('from').value;
                      var EndDate= document.getElementById('to').value;
                      var eDate = new Date(EndDate);
                      var sDate = new Date(StartDate);
                      if(StartDate!= '' && EndDate!= '' && sDate > eDate)
                        {
                        
                        document.getElementById('to').value="";
                        return false;
                        }
                    }
                    </script>
                         <script>
                        $(function() {
                  $(document).ready(function () {

                  var todaysDate = new Date(); // Gets today's date
                    var year = todaysDate.getFullYear();                        // YYYY
                    var month = ("0" + (todaysDate.getMonth() + 1)).slice(-2);  // MM
                    var day = ("0" + todaysDate.getDate()).slice(-2);           // DD
                    var minDate = (year +"-"+ month +"-"+ day); // Results in "YYYY-MM-DD" for today's date 
                    $('#from').attr('min',minDate);
                    $('#to').attr('min',minDate);
                  });
                });

                </script>
</body>
</html>