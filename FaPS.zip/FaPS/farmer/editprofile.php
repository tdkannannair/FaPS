<!DOCTYPE HTML>
<html lang="en-US">
<head>
	 
	<title>Fruit Shop | Home Style 11</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color7.css" media="all"/> 
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/edit.css" media="all"/> 
	<link rel="stylesheet" type="text/css" href="css/editpic.css" media="all"/> 
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
								<li><a href="../login.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
								<li><a href="#"><span class="color2"><i class="fa fa-check-circle-o"></i></span>Change password</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">;
				<div class="container">
			<div><h3 style="float:left;color: black; font-size:40px;line-height: 25px">welcome</h3><h3 style="float: right;color: black; font-size:40px;line-height: 25px"> farmer</h3></div>	 
			</div>
			<div class="main-header main-header7 main-header11">
				<div class="container">
					<div class="row">
						 
						 
						 
					</div>
				</div>
			</div>
			<!-- End Main Header -->
			<div class="nav-header bg-white nav-header11 header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
							<li class="current-menu-item menu-item-has-children">
								<a href="farmer.php">Home</a>
								 
							</li>
							 
							<li><a href="add_product.php">add product</a></li>
							<li><a href="product.php">my products</a></li>
							<li><a href="producTLIST.php">bedates</a></li>
						</ul>
						<a href="#" class="toggle-mobile-menu"><span></span></a>
					</nav>
				 </div>
			</div>
			<!-- End Nav Header -->
		</div>
	</header>
 
 

<div class="container form__wrapper"> 

<h2>Edit Client Profile</h2>

<form id="myForm">

<div class="bar">
<?php
include("dbconnect.php");
$sql="SELECT * FROM `docreg` WHERE id='4'";
$result=mysqli_query($con,$sql);
 											 			
 $row=mysqli_fetch_assoc($result); 
	 	 
			?>
</div>
<div class="profile-photo-div" id="profile-photo-div">
  <div class="profile-img-div" id="profile-img-div">
    <div id="loader"></div><img id="profile-img" src="images/upload/<?php echo $row['pic']?>"/>
    <input id="x-position" type="range" name="x-position" value="0" min="0"/>
    <input id="y-position" type="range" name="y-position" value="0" min="0"/>
  </div>
  <div class="profile-buttons-div">
    <div class="profile-img-input" id="profile-img-input">
      <label class="button" id="change-photo-label" for="change-photo">UPLOAD PHOTO</label>
      <input id="change-photo" name="change-photo" type="file" style="display: none;" accept="image/*"/>
    </div>
    <div class="profile-img-confirm" id="profile-img-confirm" style="display: none;">
      <div class="button half green" id="save-img"><i class="fa fa-check" aria-hidden="true"></i></div>
      <div class="button half red" id="cancel-img"><i class="fa fa-remove" aria-hidden="true"></i></div>
    </div>
  </div>
</div>
<div class="error" id="error">min sizes 400*400px</div>
<canvas id="croppedPhoto" width="400" height="400"></canvas>
  <div class="form-row">

	<div class="form-group col-md-6">

	  <label for=" Name">name</label>
	  <input name="Name" type="text" class="form-control" placeholder="<?php echo $row['shope_name']?>">

	</div><!-- /form-group -->

	<div class="form-group col-md-6">

	  <label  >place</label>
	  <input name="place" type="text" class="form-control" id="lastName" placeholder="curent place">

	</div><!-- /form-group -->

  </div><!-- /form-row -->

  <div class="form-group">

	<label for="company">Company</label>
	<input name="company" type="text" class="form-control" id="company" placeholder="Company">

  </div><!-- /form-group -->
  
  <div class="form-group">

	<label for="street">Street</label>
	<input name="street" type="text" class="form-control" id="street" placeholder="Street">

  </div><!-- /form-group -->

  <div class="form-row">

	<div class="form-group col-md-6">

	  <label for="city">City</label>
	  <input name="city" type="text" class="form-control" id="city" placeholder="City">

	</div><!-- /form-group -->

	<div class="form-group col-md-4">

	  <label for="state">State</label>
	  <input name="state" type="text" class="form-control" id="state" placeholder="State">

	</div><!-- /form-group -->

	<div class="form-group col-md-2">

	  <label for="zipCode">Zip Code</label>
	  <input name="zipCode" type="text" class="form-control" id="zipCode" placeholder="Zip code">

	</div><!-- /form-group -->

  </div><!-- /form-row -->

  <div class="form-row">

	<div class="form-group col-md-6">

	  <label for="homeNumber">Home Number</label>
	  <input name="homeNumber" type="tel" class="form-control" id="homeNumber" placeholder="Home number">

	</div><!-- /form-group -->

	<div class="form-group col-md-6">

	  <label for="faxNumber">Fax Number</label>
	  <input name="faxNumber" type="tel" class="form-control" id="faxNumber" placeholder="Fax number">

	</div><!-- /form-group -->

  </div><!-- /form-row -->

  <div class="form-row form__comments">

	<div id="form__comments-by" class="form-group col-md-6"></div>
	<div id="form__comments-txt" class="form-group col-md-6"></div>

  </div><!-- /form-row -->

  <div class="form__btns">

	<button id="cancel" class="btn btn-outline-primary">Cancel</button>
	<button id="save" class="btn btn-primary">Save</button>

  </div><!-- /form__btns -->

</form>
 
	 
</div><!-- /container -->  

<footer class="text-center text-small">

<p>&copy; <span id="currentYear"></span> Best Goods Inc. All rights reserved.</p>

<ul class="list-inline">
  <li class="list-inline-item"><a href="#">Privacy</a></li>
  <li class="list-inline-item"><a href="#">Terms</a></li>
  <li class="list-inline-item"><a href="#">Support</a></li>
</ul>

</footer>
   
			</div>
		</div>
		<!-- End Product Type -->
		<div class="newsletter-box text-center bg-color2">
			<div class="container">
				<ul class="inner-newsletter white list-inline-block">
					 
				</ul>
			</div>
		</div>
	</section>
	<!-- End Content -->
	<footer id="footer">
		<div class="footer3">
			<div class="footer-top3">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc">Phone 8848182799</p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3">For better experience give your valuable feed back through messages <a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			</div>
		 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/edit.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/editprofile.js"></script>
</body>
</html>