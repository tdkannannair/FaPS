feather.replace();

particlesJS("particles-js", {
  particles: {
    number: {
      value: 400,
      density: {
        enable: true,
        value_area: 1000
      }
    },
    color: {
      value: "#ffffff"
    },
    shape: {
      type: "circle",
      stroke: {
        width: 0,
        color: "#000000"
      }
    },
    opacity: {
      value: 0.6
    },
    size: {
      value: 5,
      random: true
    },
    line_linked: {
      enable: true,
      distance: 100,
      color: "#ffffff",
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 3,
      out_mode: "out"
    }
  },
  retina_detect: true
});
 
const MS_PER_DAY = 1000 * 60 * 60 * 24

function calcYears(today, skills) {
  years_of_exp = {}
  
  skills.forEach(function(s) {
    
    let start_date = new Date(s.date)
    
    let today_UTC = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())

    let start_date_UTC = Date.UTC(start_date.getFullYear(), start_date.getMonth(), start_date.getDate())
    
    let years = (Math.floor((today_UTC - start_date_UTC) / MS_PER_DAY) / 365).toFixed(2)
    
    years_of_exp[s.name] = years
  })
  
  return years_of_exp
}

const today = new Date()
const skill_and_exp = calcYears(today, skills)

const data = {
  labels: Object.keys(skill_and_exp),
  datasets: [
    {
      values: Object.values(skill_and_exp),
    }
  ]
};


const chart = new Chart({
  parent: '#chart',
  title: 'Superficial Estimate of Years Using [Insert Technology Here]...',
  data: data,
  type: 'bar',
  format_tooltip_y: d => d === 1 ? d + ' year' : d + ' years',
  height: 400,
  // is_navigable: 1
  
});

/*
chart.parent.addEventListener('data-select', (e) => {
    console.log(e.index);
});
*/


const generateLuckyNums = (length, max) => [...new Array(length)].map(() => Math.round(Math.random() * max))

document.getElementById('lucky').innerHTML = `Some lucky numbers for you: ${generateLuckyNums(5, 100).join(', ')}`


// Mapbox stuff

/*
// Mapbox GL
mapboxgl.accessToken = "pk.eyJ1IjoiYW5kcmV3Y2hvdSIsImEiOiJjajJqeXR5b2cwMGRiMnFucW53NWJmNjlnIn0.LmmouuLX7C6EE61cOUez3A";

var map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v8',
  center: [-95, 40],
  zoom: 2.5
})


map.on('load', function () {
  map.addLayer({
    id: "places",
    type: "symbol",
    source: {
      type: "geojson",
      data: {
        type: "FeatureCollection",
        features: [{
          type: "Feature",
          properties: {
          city: "Port Washington",
          state: "New York",
          periodStart: "1997",
          periodEnd: "2015",
          description: "I grew up here. Not much of a choice for this one.",
          icon: "marker"
        },
        geometry: {
          type: "Point",
          coordinates: [-73.71006, 40.848415]
        }
      }, {
        type: "Feature",
        properties: {
          city: "Austin",
          state: "Texas",
          periodStart: "2015",
          periodEnd: "2019 (hopefully)",
          description: "Pursuing a B.S. in mathematics with a ~certificate~ in computer science at <a href='https://www.utexas.edu/' target='_blank'>UT Austin</a> (emphasis on the B.S. 😉).",
          icon: "marker"
        },
        geometry: {
          type: "Point",
          coordinates: [-97.748306, 30.285085]
        }
      }, {
        type: "Feature",
        properties: {
          city: "Seattle",
          state: "Washington",
          periodStart: "2016 (Summer)",
          periodEnd: null,
          description: "Spent the summer with my twin brother, who goes to UW. Also worked as a cashier at the <a href='https://www.pacificsciencecenter.org/' target='_blank'>Pacific Science Center</a>.",
          icon: "marker"
        },
        geometry: {
          type: "Point",
          coordinates: [-122.3321, 47.6062]
        }
      }, {
        type: "Feature",
        properties: {
          city: "Chicago",
          state: "Illinois",
          periodStart: "2017 (Summer)",
          periodEnd: null,
          description: "Worked as a data intern at <a href='https://nexttier.com/' target='_blank'>NextTier Education</a>. I also worked remotely as a mapping intern for the <a href='https://www.hotosm.org/'  target='_blank'>Humanitarian OpenStreetMap Team</a> (HOT).",
          icon: "marker"
        },
        geometry: {
          type: "Point",
          coordinates: [-87.630385, 41.882331]
        }
      }]
      }
    },
    layout: {
      "icon-image": "{icon}-11",
      "icon-allow-overlap": true
    },
  })

  map.on('click', 'places', function (e){
    
    let content = `
 <h5 class="popup-city-name">${e.features[0].properties.city +
        ", " + e.features[0].properties.state}</h5>

    <p class="popup-text"><b class="lead">WHEN</b>: ${e.features[0].properties.periodStart} ${e.features[0].properties.periodEnd !== null
        ? `- ${e.features[0].properties.periodEnd}`
        : ""}</p>

    <p class="popup-text"><b class="lead">WHY</b>: ${e.features[0].properties.description}</p>`;
    
    
    new mapboxgl.Popup({anchor: 'bottom'})
    .setLngLat(e.features[0].geometry.coordinates)
    .setHTML(content)
    .addTo(map);
    
    
    let latZoom = e.features[0].geometry.coordinates[0]
    let longZoom = e.features[0].geometry.coordinates[1]
    map.flyTo({center: [latZoom, longZoom + 5]});
    
  });
  
  map.on('mouseenter', 'places', function (){
    map.getCanvas().style.cursor = 'pointer';
  });
  
  map.on('mouseleave', 'places', function () {
        map.getCanvas().style.cursor = '';
    });
  
  
});
*/

// Mapbox JS
L.mapbox.accessToken =
  "pk.eyJ1IjoiYW5kcmV3Y2hvdSIsImEiOiJjajJqeXR5b2cwMGRiMnFucW53NWJmNjlnIn0.LmmouuLX7C6EE61cOUez3A";

var map = L.mapbox
  .map("map", "mapbox.streets", { zoomControl: false })
  .setView([40, -95], 3);

L.control
  .zoom({
    position: "topright"
  })
  .addTo(map);

// Create marker layer
const currentLocation = "#228b22";
const markerColor = "#156a9e";
const markerSize = "small";

const featureData = {
  type: "FeatureCollection",
  features: [
    {
      type: "Feature",
      properties: {
        city: "Port Washington",
        state: "New York",
        periodStart: "1997",
        periodEnd: "2015",
        description: "I grew up here. Not much of a choice for this one.",
        "marker-color": markerColor,
        "marker-size": markerSize,
        "marker-symbol": "1"
      },
      geometry: {
        type: "Point",
        coordinates: [-73.71006, 40.848415]
      }
    },
    {
      type: "Feature",
      properties: {
        city: "Austin",
        state: "Texas",
        periodStart: "2015",
        periodEnd: "2018",
        description:
          "Pursuing a B.S. in mathematics with a ~certificate~ in computer science @ <a href='https://www.utexas.edu/' target='_blank'>UT Austin</a>. Emphasis on the B.S. 😉",
        "marker-color": currentLocation,
        "marker-size": markerSize,
        "marker-symbol": "2"
      },
      geometry: {
        type: "Point",
        coordinates: [-97.748306, 30.285085]
      }
    },
    {
      type: "Feature",
      properties: {
        city: "Seattle",
        state: "Washington",
        periodStart: "2016 (Summer)",
        periodEnd: null,
        description:
          "Spent the summer with my twin brother, who goes to UW, and worked as a cashier @ <a href='https://www.pacificsciencecenter.org/' target='_blank'>Pacific Science Center</a>.",
        "marker-color": markerColor,
        "marker-size": markerSize,
        "marker-symbol": "3"
      },
      geometry: {
        type: "Point",
        coordinates: [-122.3321, 47.6062]
      }
    },
    {
      type: "Feature",
      properties: {
        city: "Chicago",
        state: "Illinois",
        periodStart: "2017 (Summer)",
        periodEnd: null,
        description:
          "Data intern @ <a href='https://nexttier.com/' target='_blank'>NextTier Education</a> and mapping intern @ <a href='https://www.hotosm.org/'  target='_blank'>Humanitarian OpenStreetMap Team</a> (HOT).",
        "marker-color": markerColor,
        "marker-size": markerSize,
        "marker-symbol": "4"
      },
      geometry: {
        type: "Point",
        coordinates: [-87.630385, 41.882331]
      }
    }
  ]
};

const markerLayer = L.mapbox
  .featureLayer(featureData)
  .on("click", function(e) {
    let lat = e.layer.getLatLng().lat;
    let long = e.layer.getLatLng().lng;

    map.flyTo({ lat: lat + 10, lng: long });
  })
  .addTo(map);

markerLayer.eachLayer(function(layer) {
  let content = `
<h5 class="popup-city-name">${layer.feature.properties.city +
    ", " +
    layer.feature.properties.state}</h5>

<p class="popup-text"><b class="lead">WHEN</b>: ${layer.feature.properties
    .periodStart} ${layer.feature.properties.periodEnd !== null
    ? `- ${layer.feature.properties.periodEnd}`
    : ""}</p>

<p class="popup-text"><b class="lead">WHY</b>: ${layer.feature.properties
    .description}</p>
`;

  layer.bindPopup(content);
});
(function(a){function d(b){var c=b||window.event,d=[].slice.call(arguments,1),e=0,f=!0,g=0,h=0;return b=a.event.fix(c),b.type="mousewheel",c.wheelDelta&&(e=c.wheelDelta/120),c.detail&&(e=-c.detail/3),h=e,c.axis!==undefined&&c.axis===c.HORIZONTAL_AXIS&&(h=0,g=-1*e),c.wheelDeltaY!==undefined&&(h=c.wheelDeltaY/120),c.wheelDeltaX!==undefined&&(g=-1*c.wheelDeltaX/120),d.unshift(b,e,g,h),(a.event.dispatch||a.event.handle).apply(this,d)}var b=["DOMMouseScroll","mousewheel"];if(a.event.fixHooks)for(var c=b.length;c;)a.event.fixHooks[b[--c]]=a.event.mouseHooks;a.event.special.mousewheel={setup:function(){if(this.addEventListener)for(var a=b.length;a;)this.addEventListener(b[--a],d,!1);else this.onmousewheel=d},teardown:function(){if(this.removeEventListener)for(var a=b.length;a;)this.removeEventListener(b[--a],d,!1);else this.onmousewheel=null}},a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})})(jQuery)