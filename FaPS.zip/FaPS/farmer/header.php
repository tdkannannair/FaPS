<div class="nav-header bg-white header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
							<li class="current-menu-item menu-item-has-children">
								<a href="admin.php">Home</a>
								 
							</li>
							 
							<li class="menu-item-has-children">
								<a href="">add</a>
								<ul class="sub-menu">
									<li><a href="add_panch_officer.php">Panchayath Officer</a></li>
									<li><a href="add_agre_officer.php">Agriculture Officer</a></li>
									<li><a href="addcatagory.php">catagory</a></li>
									 
										 
									</li>
									 
									 
								</ul>
							</li>
						<li class="menu-item-has-children">
								<a href="products.php">Product</a>
								<!-- <ul class="sub-menu">
									<li><a href=" "> for Sale</a></li>
									<li><a href=" ">Sold Products</a></li>
									<li><a href=" ">Delete product</a></li>
								</ul> -->
							</li>
							<li class="menu-item-has-children">
								<li class="menu-item-has-children">
								<a href="">Users</a>
								<ul class="sub-menu">
									<li><a href="farmers.php">Farmer</a></li>
									<li><a href="shopkeepers.php">Shopkeeper</a></li>
									<li class="menu-item-has-children">
										<a href="">Officer</a>
										<ul class="sub-menu">
											<li><a href="panchayath.php">Panchayath</a></li>
											<li><a href="agre_officer.php">Agriculture</a></li>
											 
										</ul>
									</li>
								</ul>
							</li>
							<!--<li class="menu-item-has-children">
								<a href="#">Location</a>
								<ul class="sub-menu">
									<li><a href="blog-list.html">Farmers</a></li>
									<li><a href="blog-masonry.html">shopkeeper</a></li>
									<li><a href="blog-detail.html">Region</a></li>
								</ul>
							</li>-->
							<li><a href="messages.php">Messages</a></li>
							 
						</ul>
						<a href="messages.php" class="toggle-mobile-menu"><span></span></a>
					</nav>
				</div>
			</div>