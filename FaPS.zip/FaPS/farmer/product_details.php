<!DOCTYPE HTML>
<html lang="en-US">
<head>
<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
<meta charset="utf-8"> 
	<title>Details</title>
	 <link rel="stylesheet" href="css/mod.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color7.css" media="all"/> 
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
	 <meta name="viewport" content="width=device-width, initial-scale=1">
 

</head>
<body class="preload">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
								<li><a href="#"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
								<li><a href="#"><span class="color2"><i class="fa fa-check-circle-o"></i></span>Change password</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">;
				<div class="container">
			<dv><h3 style="float:left;color: black; font-size:40px;line-height: 25px">welcome</h3><h3 style="float: right;color: black; font-size:40px;line-height: 25px"> shopkeeper</h3></dv>	 
			</div>
			<div class="main-header main-header7 main-header11">
				<div class="container">
					<div class="row">
						 
						 
						 
					</div>
				</div>
			</div>
			<!-- End Main Header -->
			<div class="nav-header bg-white nav-header11 header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
							<li class="current-menu-item menu-item-has-children">
								<a href="index.html">Home</a>
								 
							</li>
							 
							<li><a href="#">Features</a></li>
							<li><a href="#">Pages</a></li>
							 
							<li class="menu-item-has-children">
								<a href="#">Blog</a>
								<ul class="sub-menu">
									<li><a href="blog-list.html">Blog List</a></li>
									<li><a href="blog-masonry.html">Blog Masonry</a></li>
									<li><a href="blog-detail.html">Blog Detail</a></li>
								</ul>
							</li>
							 
							<li><a href="contact.html">Contact</a></li>
						</ul>
						<a href="#" class="toggle-mobile-menu"><span></span></a>
					</nav>
				 </div>
			</div>
			<!-- End Nav Header -->
		</div>
	</header>
	<!-- End Header -->
	<section id="content">
		<div class="container">
		 <br><br><br><br><br><br>
					<br>
			<!-- End Banner Slider -->
			<div class="shop-policy11">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">curent product</h2>
							<a href="#"><img src="images/home/home11/ad1.jpg" alt="" /></a>
							<p class="desc">With €50 or more orders</p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">sold</h2>
							<a href="#"><img src="images/home/home11/ad2.jpg" alt="" /></a>
							<p class="desc">Find Fruit meals and treats in a store near you.</p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="item-policy11 text-center">
							<h2 class="title18 font-bold">Compare Organic Food</h2>
							<a href="#"><img src="images/home/home11/ad3.jpg" alt="" /></a>
							<p class="desc">Discover how fresh is different from other Fruit food.</p>
						</div>
					</div>
				</div>
			</div>
			<!-- End Shop Policy -->
		</div>
		 
		<!-- End Product Box -->
		 
			<!-- End List Adv -->
		 
	 
		 <div class="product-bestsale best-sale6">
		 <div id="myModal" class="modal fade" role="dialog">
  											<div class="modal-dialog">

   												 <!-- Modal content-->
   														 <div class="modal-content">
     														 <div class="modal-header">
      															  <button type="button" class="close" data-dismiss="modal">&times;</button>
       																 <h4 class="modal-title">Show Interest</h4>
     																	 </div>
     													 <div class="modal-body">
														  
				<label for="exampleMobile1">   enter the rate that you can pay for the product </label>
				<input type="text" name="rate" id="rate"required>
				<label for="exampleMobile1">  Choose yes if you cacn provide transportatiin fecilities </label>
				 <input type="radio" name="trans" value="yes"   checked> 
				 no
  <input type="radio" name="trans" value="no"> yes
		 
     														 </div>
															  
     												 <div class="modal-footer">
      														  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
     													 </div>
    														</div>

 												</div>
											</div>
		 <br>
		 <br>
				<h2 class="title30 font-bold title-box1 text-uppercase text-center"> Products</h2>
				<div class="product-loadmore">
					<div class="row">
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_32.jpg" alt="">
										<img src="images/product/fruit_33.jpg" alt="">
									</a>
									  
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<ins class="color"><span>320rs</span></ins>
									 
										<ins class="color"><span>date</span></ins>
									</div> 
									 <div class="product-extra-link">
										 
									   <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"> message</button>
										  
									   
	 								 
	 								 
	 								  </div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_35.jpg" alt="">
										<img src="images/product/fruit_36.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Apetito Pure Fruit Juice</a></h3>
									<div class="product-price">
										<del class="silver"><span>€470.00</span></del>
										<ins class="color"><span>€450.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_13.jpg" alt="">
										<img src="images/product/fruit_12.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Aurore Grape</a></h3>
									<div class="product-price">
										<ins class="color"><span>€290.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_10.jpg" alt="">
										<img src="images/product/fruit_18.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<del class="silver"><span>€630.00</span></del>
										<ins class="color"><span>€170.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_11.jpg" alt="">
										<img src="images/product/fruit_27.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<del class="silver"><span>€630.00</span></del>
										<ins class="color"><span>€170.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_01.jpg" alt="">
										<img src="images/product/fruit_04.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<del class="silver"><span>€630.00</span></del>
										<ins class="color"><span>€170.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_02.jpg" alt="">
										<img src="images/product/fruit_01.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<ins class="color"><span>€30.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_03.jpg" alt="">
										<img src="images/product/fruit_04.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Apetito Pure Fruit Juice</a></h3>
									<div class="product-price">
										<del class="silver"><span>€470.00</span></del>
										<ins class="color"><span>€450.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_32.jpg" alt="">
										<img src="images/product/fruit_33.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<ins class="color"><span>€30.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_35.jpg" alt="">
										<img src="images/product/fruit_36.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Apetito Pure Fruit Juice</a></h3>
									<div class="product-price">
										<del class="silver"><span>€470.00</span></del>
										<ins class="color"><span>€450.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_13.jpg" alt="">
										<img src="images/product/fruit_12.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Aurore Grape</a></h3>
									<div class="product-price">
										<ins class="color"><span>€290.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
						<div class="col-md-3 col-sm-4 col-xs-6">
							<div class="item-product item-product1 text-center border bg-white">
								<div class="product-thumb">
									<a href="detail.html" class="product-thumb-link rotate-thumb">
										<img src="images/product/fruit_10.jpg" alt="">
										<img src="images/product/fruit_18.jpg" alt="">
									</a>
									<a href="quick-view.html" class="quickview-link fancybox fancybox.iframe"><i class="fa fa-search" aria-hidden="true"></i></a>
								</div>
								<div class="product-info">
									<h3 class="product-title"><a href="detail.html">Fresh Meal Kit</a></h3>
									<div class="product-price">
										<del class="silver"><span>€630.00</span></del>
										<ins class="color"><span>€170.000</span></ins>
									</div>
									<div class="product-rate">
										<div class="product-rating" style="width:100%"></div>
									</div>
									<div class="product-extra-link">
										<a href="#" class="wishlist-link"><i class="fa fa-heart-o" aria-hidden="true"></i><span>Wishlist</span></a>
										<a href="#" class="addcart-link">Add to cart</a>
										<a href="#" class="compare-link"><i class="fa fa-compress" aria-hidden="true"></i><span>Compare</span></a>
									</div>
								</div>
							</div>
						</div>
						<!-- End Item -->
					</div>
					 
				</div>
			</div>
		<!-- End Client Review -->
		 
							<div class="pagibar text-center">
								<a href="#" class="current-page">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#" class="next-page"> <i class="icon ion-ios-arrow-thin-right"></i></a>
							</div>
						</div>
						</div>
		<!-- End Product Type -->
		<div class="newsletter-box text-center bg-color2">
			<div class="container">
				<ul class="inner-newsletter white list-inline-block">
					<li><h2 class="title30"><i class="fa fa-envelope-open"></i>MESSAGE </h2></li>
					<li><p>This message will be send to the ADMIN</p></li>
					<li>
						<form class="email-form">
							<input onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="message" type="text">
							<input type="submit" value="Send">
						</form>
					</li>
				</ul>
			</div>
		</div>
	</section>
	<!-- End Content -->
	<footer id="footer">
		<div class="footer3">
			<div class="footer-top3">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc">Phone 8848182799</p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3">For better experience give your valuable feed back through messages <a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			</div>
		 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
  <script src="js/mod.js"></script>
  <script src="js/mod1.js"></script>
</body>
</html>