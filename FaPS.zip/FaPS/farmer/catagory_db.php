 <?php
 session_start();
include 'dbconnect.php';
 
 
if (! empty($_POST["cat_id"])) {
  $c_id=$_POST["cat_id"];

  $query=mysqli_query($con,"SELECT * FROM subcatagory WHERE cat_id ='$c_id'");
  echo "<option  value disabled selected>Select sub catagory</option>";
  while($row=mysqli_fetch_array($query))
  {
	echo "<option   value='".$row["id"]."'>".$row["subcat_name"]."</option>";
	 
  }
}

?>