<!DOCTYPE HTML>
<?php
include('../dbconnect.php');
session_start();
$email=$_SESSION['email'];
$pname=$_POST['product'];
  
$eml=$_SESSION['email'];
$pas=$_SESSION['password'];
$sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
$sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){



?>
<html lang="en-US">
<head>
<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
<meta charset="utf-8"> 
	<title> bid\rates</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color7.css" media="all"/> 
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/chat2.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/chat.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
							<li><a href="../tool/logout.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
								 
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">;
				<div class="container">
			<div><h3 style="float:left;color: black; font-size:40px;line-height: 25px">welcome</h3><h3 style="float: right;color: black; font-size:40px;line-height: 25px"> <?php echo $nm; ?></h3></div>	 
			</div>
			<div class="main-header main-header7 main-header11">
				<div class="container">
					<div class="row">
						 
						 
						 
					</div>
				</div>
			</div>
			<!-- End Main Header -->
			<div class="nav-header bg-white nav-header11 header-ontop">
				<div class="container">
					<nav class="main-nav main-nav1">
						<ul>
						<li class="current-menu-item menu-item-has-children">
								<a href="farmer.php">Home</a>
								 
							</li>
							 
							<li><a href="add_product.php">add product</a></li>
							<li><a href="product.php">my products</a></li>
							<li><a href="producTLIST.php">bedates</a></li>
						</ul>
						<a href="#" class="toggle-mobile-menu"><span></span></a>
					</nav>
				 </div>
			</div>
			<!-- End Nav Header -->
		</div>
	</header>
	<!-- End Header -->
	<section id="content">
		<div class="container">
		 <br><br><br><br><br><br>
					<br>
			<!-- End Banner Slider -->
		 
			<!-- End Shop Policy -->
		</div>
		 
		<!-- End Product Box -->
		 
		<!-- End Product Box -->
		<div class="from-blog8">
			<div class="container">
				<h2 class="title30 font-bold text-center">preposed products </h2>
				<?php
				 
					 	$sql = "SELECT * FROM product WHERE subcatagory ='$pname' and email='$eml' and sales=0  ";
											 $result=mysqli_query($con,$sql);
											 			
											if (mysqli_num_rows($result) > 0) {
												while($row = mysqli_fetch_assoc($result)) {
												 
													 
													?>
											 
	<!-- End Header -->	<div class="blog-slider8">
				 
		 
        <div class="messages">

         
		 
		 

<a href="showbid.php?id=<?php echo $row['id']?>" class="messages__item">
		<div class="name">
		<?php echo $row['date']?>
		</div>
		<div class="date">
		 
		 
		 <img src="images/20.jpg" width="90" height="70" alt="Computer Hope">
		</div>
		<div class="content">
		   <h4> <?php echo $row['rate']?>.RS</h4>  
		   <h4> <?php echo $row['quantity']?>.kg</h4> 
		</div>
		
		</a>
		 
</div>
	 
	</div>
	
  <?php
												}
											} else {
												echo "0 results";
											}

										?>
  
			
			</div>
		</div>
		<!-- End From Blog -->
	 
		<!-- End Client Review --> 
		<!-- End Product Type -->
		 
	</section>
	<!-- End Content -->
	<footer id="footer">
		<div class="footer3">
			<div class="footer-top3">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="footer-box3">
								<h2 class="title30 font-bold">Contact us</h2>
								<p class="desc">Phone 8848182799</p>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<p class="desc more-contact3">For better experience give your valuable feed back through messages <a href="#" class="color"> </a></p>
						</div>
					</div>
				</div>
			</div>
		 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/modernizr.custom.js"></script>
<script type="text/javascript" src="js/libs/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
</body>
<?php

}
else
{
    header("location:../login.php");
}
?>
</html>