 <?php
 session_start();
include 'dbconnect.php';
	$catagory =$_POST['ADD_CAT'];
 
	$sql = "SELECT * FROM  catagory ";
	$result=mysqli_query($con,$sql);
	if (mysqli_num_rows($result) > 0) {
											 
		while($row = mysqli_fetch_assoc($result)) {
	
			$d=$row['cat_name'];
		 
			if($d == $catagory)
			{
				$A=1;
			}
		}
	}
	 
    if($A==1){

header("location:addcatagory.php?error=catagory alredy exists");
		$sql4="INSERT INTO catagory (cat_name) VALUES ('$catagory')";
		$result=mysqli_query($con,$sql4);
	}
	else{
		header("location:addcatagory.php");

	}
	 

 

   

  
?>
