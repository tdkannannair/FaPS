<?php
	include("../dbconnect.php");
	$id=$_POST['id']; 
	$sql2 = "SELECT * FROM registeration where id='$id'";
	$result2=mysqli_query($con,$sql2);
	$row2 = mysqli_fetch_assoc($result2);
	$e=$row2['name'];
	$query="delete from login where email='$e'"; 
	$query_exe=mysqli_query($con,$query);
 ?>