<?php
	include("../dbconnect.php");
	$id=$_POST['id']; 
	$query="delete from product where id='$id'"; 

	$query_exe=mysqli_query($con,$query);
	 
	$sql = "SELECT * FROM `product` WHERE id='$id'";
	$result=mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($result);


	$e=row['email'];
	$i=row['published'];
	$n=$row['name'];
	$noti='your product'.$n'which is been published on'.$i.'was been deleted by the admin';
	$query="INSERT INTO notification(content,date,sender,receiver,status,type) VALUES ('$noti','$date','admin','$e','0','admin')";
	
	$query_exe=mysqli_query($con,$query);
 
 ?>