<?php
	include("../dbconnect.php");
	$id=$_POST['id']; 
	 
	$query="UPDATE login SET status ='1' where reg_id='$id'"; 
	$query_exe=mysqli_query($con,$query);
 ?>