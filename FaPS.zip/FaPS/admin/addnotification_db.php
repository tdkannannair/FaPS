 <?php
	include("dbconnect.php");
	session_start();
    	 
	$noti=$_POST['noti'];
	$user=$_POST['user'];
	$date=date("y/m/d");

 
 $query="INSERT INTO notification(content,date,sender,receiver,status,type) VALUES ('$noti','$date','8','$user','0','admin')";
	
	$query_exe=mysqli_query($con,$query);
 
	 
	header("location:notificationedit.php");
	
?> 