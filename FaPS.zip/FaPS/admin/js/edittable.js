var row;

$('#edit-TreatmentPlan').click(function() {
	$('td:last-child(), th:last-child(), #add-row-TreatmentPlan').toggle();
});

$('#save-TreatmentPlanRowDialog').click(function() {

	// TODO: save data to backend
	// get row-id attribute of the clicked element's row
	var rowId = row.attr('id');

	// update row values
	var modalContent = $(this).closest('.modal-content');
	var date = modalContent.find('input[name="date"]').val();
	var protocol = modalContent.find('input[name="protocol"]').val();
	var operator = modalContent.find('#dropdownOperator').text();

	row.find('.date').text(date);
	row.find('.protocol').text(protocol);
	row.find('.operator').text(operator);

	// we're done, close modal
	$('#treatmentPlanRowDialog').modal('hide');
});

//triggered when modal is about to be shown
$('#treatmentPlanRowDialog').on('show.bs.modal', function(e) {

	// get row
	row = $(e.relatedTarget).closest('tr');

	// get values from row
	var rowDate = row.find('.date').text();
	var rowProtocol = row.find('.protocol').text();
	var rowOperator = row.find('.operator').text();

	//populate modal
	$(e.currentTarget).find('input[name="date"]').val(rowDate);
	$(e.currentTarget).find('input[name="protocol"]').val(rowProtocol);
	$(e.currentTarget).find('#dropdownOperator').html(rowOperator + ' <span class="caret"></span>');
});

//triggered when modal is about to be shown
$('#deleteTableRowDialog').on('show.bs.modal', function(e) {
	// get row
	row = $(e.relatedTarget).closest('tr');
});

// delete row
$('#delete-TreatmentPlanRow').click(function(e) {

	// TODO: delete row in backend
	// get row-id attribute of the clicked element's row
	var rowId = row.attr('id');

	// remove from frontend
	row.remove();

	// we're done, close modal
	$('#deleteTableRowDialog').modal('hide');
});

// general handling of dropdown menu to replace the default value with the selected value
$(".dropdown-menu li a").click(function() {
	$(this).parents(".dropdown").find('.btn').html($(this).text() + ' <span class="caret"></span>');
	$(this).parents(".dropdown").find('.btn').val($(this).data('value'));
});

$("#add-row-TreatmentPlan").click(function() {
	// get row id, add 1 for increment
	var i = parseInt($("#treatment-plan table").find("tr").last().attr('id').replace('treatment-plan-row', ''));
	$('#treatment-plan-row' + i).html('<td class="date"></td>' +
		'<td class="protocol"></td>' +
		'<td></td>' +
		'<td></td>' +
		'<td class="operator"></td>' +
		'<td></td>' +
		'<td>' +
		'<a href="#treatmentPlanRowDialog" data-toggle="modal">Edit</a> ' +
		'<a href="#deleteTableRowDialog" data-toggle="modal">Delete</a>' +
		'</td>');

	$('#treatment-plan table').append('<tr id="treatment-plan-row' + (i + 1) + '"></tr>');
	i++;
});