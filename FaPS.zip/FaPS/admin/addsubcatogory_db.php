 <?php
 session_start();
include 'dbconnect.php';
	$catagory =$_POST['catagory'];
 
	$ADD_sub_CAT =$_POST['ADD_sub_CAT'];
	 
	 
 
	$sql = "SELECT * FROM subcatagory";
	$result=mysqli_query($con,$sql);
	if (mysqli_num_rows($result) > 0) {
											 
		while($row = mysqli_fetch_assoc($result)) {
	
			$d=$row['subcat_name'];
		 
			if($d == $ADD_sub_CAT)
			{
				$A=1;
			}
		}
	}
	 
    if($A==1){

		header("location:addcatagory.php?error=subcatagory alredy exists");
	 
		 
	}
	else{
		$sql4="INSERT INTO subcatagory (cat_id,subcat_name) VALUES ('$catagory','$ADD_sub_CAT')";
		$result=mysqli_query($con,$sql4);
		header("location:addcatagory.php");

	}
	 
	
?>
