<?php
	include("../dbconnect.php");
	$id=$_POST['id']; 
	$query="delete from panchayath_office where p_id='$id'"; 
	$query_exe=mysqli_query($con,$query);
 ?>