<?php
 session_start();
 include('../dbconnect.php');
 $eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	 
	<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
<meta charset="utf-8">
	<title>Add catagory</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color4.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload" style="background:#f4f4f4">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
							<li><a href="../tool/logout.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
								 
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">
				 
			</div>
			<!-- End Main Header -->
			<?php
	include("header.php");
	?>
	<!-- End Header -->
			<div class="container">
			<div class="statistic-box">
				<h2 class="title30 font-bold text-center border-bottom">Add Category</h2>
		 
			</div>
	<section id="content">
		<div class="container">
		 
		<div class="mat-divv">
		<form  action="addcatogory_db.php" method="post">
    <label for="address" class="mat-label">ADD CATEGORY</label>
    <input type="text" class="mat-inputs" name="ADD_CAT" id="ADD_CAT" required>
  <button id="btnaddcat"> ADD</button>
</form>
</div> 
  <br>
  <div class="mat-divv">
	  
	<label for="address" class="mat-label">ADD sub CATeGORY</label>
	<div id="mainselection">
		<form  action="addsubcatogory_db.php" method="post">
  					<select name="catagory" id="cusSelectbox" required>
					<option value="select">select</option>
					<?php

				$res = mysqli_query($con,"select * from catagory");

				while($row = mysqli_fetch_array($res))
				{
				?>
			<option value="<?php echo $row["cat_id"]; ?>"><?php echo $row["cat_name"]; ?></option>
				<?php
				}
				?>
					 
				</select>
				<input type="text" class="mat-inputs"  name="ADD_sub_CAT" id="ADD_sub_CAT" required>
  <button id="btnaddsubcat"> ADD</button>
				</form>	
</div>
   </div> <?php
if(isset($_GET['error'])){
 $error=$_GET['error'];
 
echo '<span style="color:red;text-align:center;">'.$error.'!</span>';
}
?>
			<div class="list-product-type4">
				<div class="row">
				<div class="col-md-6 col-sm-6 col-xs-12">
				 <h2>	 category </h2>		
				 <table class="table">
  <thead>
    <tr>
      
      <th scope="col">name</th>
       
    </tr>
	</thead>
<?php	$sql = "SELECT * FROM  catagory ";
											 $result=mysqli_query($con,$sql);
											 			
											if (mysqli_num_rows($result) > 0) {
											 
												while($row = mysqli_fetch_assoc($result)) {
													?>
  <tbody>
    <tr>
       
       
      <td><?php echo $row['cat_name'] ?> </td>
      
    </tr>
     
	</tbody>
												<?php }} ?>
</table>
				
				
				
				
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
				<h2>	 subcategory </h2>		
				 <table class="table">
  <thead>
    <tr>
			 
			<th scope="col">Category</th>
      <th scope="col">Name</th>
       
    </tr>
	</thead>
<?php	$sql = "SELECT * FROM   subcatagory ";
											 $result=mysqli_query($con,$sql);
											 			
											if (mysqli_num_rows($result) > 0) {
											 
												while($row = mysqli_fetch_assoc($result)) {
													?>
  <tbody>
    <tr>
       
			<?php 
			$c=$row['cat_id'];
			  $sql2 = "SELECT * FROM catagory where cat_id='$c' ";
											 $result2=mysqli_query($con,$sql2);
											 $row2=mysqli_fetch_assoc($result2);
											  
			?>
			  <td><?php echo $row2['cat_name'] ?> </td>
      <td><?php echo $row['subcat_name'] ?> </td>
      
    </tr>
												<?php }}?>
  </tbody>
</table>
			</div>
				</div>
				</div>
			<!-- End Product Type -->
		 
			<!-- End Service -->
	 
	 
		<div class="list-brand">
			<div class="container">
				<div class="brand-slider">
					<div class="wrap-item" data-pagination="false" data-autoplay="true" data-itemscustom="[[0,2],[480,3],[768,4],[990,5]]">
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
</body>
<?php

}
else
{
    header("location:../login.php");
}

?>
</html>