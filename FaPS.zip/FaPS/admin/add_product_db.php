 <?php
	include("dbconnect.php");
	session_start();
    		$name = $_POST['name']; 
	        $quantity = $_POST['quantity']; 
			$price = $_POST['price']; 
			$pic = $_POST['pic']; 
			$date=date("y/m/d");
			 // $email=$_SESSION['email']; 
			 $email="tdk@gmail.com";

$photo = time().$_FILES["pic"]["name"];
move_uploaded_file($_FILES["pic"]["tmp_name"],'image/product/'.$photo);

 
  
	$query="INSERT INTO `product`(`name`, `quantity`, `rate`, `pic`, `sales`, `date`, `email`) VALUES ('$name','$quantity','$price','$pic','$photo','0','$date','$email')";

	$query_exe=mysqli_query($con,$query);
 
?>
