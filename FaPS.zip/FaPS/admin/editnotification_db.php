 <?php
	include("dbconnect.php");
	session_start();
    		$content = $_POST['content']; 
			$id=$_GET['id'];
 
		 
 
  
	$query="UPDATE notification SET  content='$content'  WHERE id='$id'";
	
	$query_exe=mysqli_query($con,$query);
 
	 
	 header("location:notificationedit.php");
	
?> 