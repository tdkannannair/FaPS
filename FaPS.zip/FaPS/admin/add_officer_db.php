<?php
	include("../dbconnect.php");
	 
			$id = $_POST['panch_id']; 
    		$pname = $_POST['pancch_name']; 
	        $district = $_POST['district']; 
			$contact = $_POST['contact']; 
			$email = $_POST['email']; 
			$password = $_POST['password'];	
			$Latitude = $_POST['Latitude'];	
			$Longitude = $_POST['Longitude'];	
			$sql = "SELECT * FROM `officer` WHERE email='$email'";
			$result=mysqli_query($con,$sql);
		 if (mysqli_num_rows($result) > 0) {
			echo "2";
 				}
			else 
			 { $sql1 = "SELECT * FROM `officer` WHERE 'name'='$pname'";
				$result1=mysqli_query($con,$sql1);
			 if (mysqli_num_rows($result1) > 0)
					{	
						echo "3";
							}
			 else{
									 
						$query="insert into officer (name,panch_name,district,contact,email,Latitude,Longitude) VALUES ('$id','$pname','$district','$contact','$email','$Latitude','$Longitude')";
						$query2="insert into login(email,type,password,status) values ('$email','officer','$password',0)";

						$query_exe2=mysqli_query($con,$query2);
						$query_exe=mysqli_query($con,$query);
						echo "1";
			 		}
				}

?> 