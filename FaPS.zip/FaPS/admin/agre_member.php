<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="description" content="Fruit Shop is new Html theme that we have designed to help you transform your store into a beautiful online showroom. This is a fully responsive Html theme, with multiple versions for homepage and multiple templates for sub pages as well" />
	<meta name="keywords" content="Fruit,7uptheme" />
	<meta name="robots" content="noodp,index,follow" />
	<meta name='revisit-after' content='1 days' />
	<title>Fruit Shop | Home Style 4</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color4.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload" style="background:#f4f4f4">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
								<li><a href="../login.php"><span class="color"><i class="fa fa-key"></i></span>Logout</a></li>
								<li><a href="#"><span class="color"><i class="fa fa-check-circle-o"></i></span>Change password</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">
				 
			</div>
			<!-- End Main Header -->
			<?php
	include("header.php");
	?>
			<!-- End Nav Header -->
		</div>
	</header>
	<!-- End Header -->
			<div class="container">
			<div class="statistic-box">
				<h2 class="title30 font-bold text-center border-bottom">Agriculture Department member</h2>
		 
			</div>
	<section id="content">
		<div class="container">
		 
			<!-- End Content Top -->
			 
			<!-- End List Service -->
	 
	 
			<!-- End Product Type -->
 
			<!-- End Product Best Sale -->
			 
			 
			<!-- End Latest News -->
			<div class="list-product-type4">
				<div class="row">
				 
 
				</div>
			</div>
			<!-- End Product Type -->
		 
			<!-- End Service -->
	 
	 
		<div class="list-brand">
			<div class="container">
				<div class="brand-slider">
					<div class="wrap-item" data-pagination="false" data-autoplay="true" data-itemscustom="[[0,2],[480,3],[768,4],[990,5]]">
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
</body>
</html>