 <?php
	include("dbconnect.php");
	session_start();
    	 
			$id=$_GET['id'];
 
		 
 
  
	$query="DELETE FROM notification WHERE id='$id'";
	
	$query_exe=mysqli_query($con,$query);
 
	 
	 header("location:notificationedit.php");
	
?> 