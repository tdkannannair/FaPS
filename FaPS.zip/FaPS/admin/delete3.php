<?php
	include("../dbconnect.php");
	$id=$_POST['id']; 
	$query="delete from product where p_id='$id'"; 
	$query_exe=mysqli_query($con,$query);
 ?>