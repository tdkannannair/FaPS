<?php

$con=@mysqli_connect("localhost","root","","FaPS")or die("unable to connect");

?>
