   <?php
	include("../dbconnect.php");
	 
			$id = $_POST['panch_id']; 
    		$name = $_POST['pancch_name']; 
	        $district = $_POST['district']; 
			$contact = $_POST['contact']; 
			$email = $_POST['email']; 
			$password = $_POST['password'];	
			  
	$query="insert into panchayath_office (panchid,panch_name,district,contact,email) VALUES ('$id','$name','$district','$contact','$email')";
	$query2="insert into login(email,type,password,status) values ('$email','panch_off','$password',0)";

	$query_exe2=mysqli_query($con,$query2);
	$query_exe=mysqli_query($con,$query);
 
?> 
