<?php
	include("../dbconnect.php");
	$id=$_POST['id'];
	
	$query="delete from agri_id where agri_id='$id'"; 
	$query_exe=mysqli_query($con,$query);
 ?>