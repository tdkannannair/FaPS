<!DOCTYPE HTML>
<html lang="en-US">
<head>
<?php
 session_start();
 include('../dbconnect.php');
 $eml=$_SESSION['email'];
 $pas=$_SESSION['password'];
 $sql7 = "SELECT * FROM  registeration WHERE email = '$eml'";
$result7=mysqli_query($con,$sql7);
$row7 = mysqli_fetch_assoc($result7);
$nm=$row7['name'];
 $sql="select * from login where email='$eml'and password='$pas'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
if($row !=0){
?>
	<link rel="shortcut icon" type="image/x-icon" href="../images/icon/favicon_tkv.png">
<meta charset="utf-8"> 
	<title>FAPS | Admin</title>
	<link rel="stylesheet" type="text/css" href="css/word.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/libs/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/ionicons.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/bootstrap-theme.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.transitions.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/jquery.mCustomScrollbar.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/owl.theme.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/slick.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/animate.css"/>
	<link rel="stylesheet" type="text/css" href="css/libs/hover.css"/>
	<link rel="stylesheet" type="text/css" href="css/color4.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/theme.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all"/>
	<link rel="stylesheet" type="text/css" href="css/browser.css" media="all"/>
	<!-- <link rel="stylesheet" type="text/css" href="css/rtl.css" media="all"/> -->
</head>
<body class="preload" style="background:#f4f4f4">
<div class="wrap">
	<header id="header">
		<div class="header">
			<div class="top-header top-header2">
				<div class="container">
					<div class="row">
					 
						<div class="col-md-8 col-sm-8 col-xs-12">
							<ul class="info-account list-inline-block pull-right">
								 
							<li><a href="../tool/logout.php"><span class="color2"><i class="fa fa-key"></i></span>Logout</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Top Header -->
			<div class="main-header bg-color2">
				<div class="container">
					<div class="row">
						<div class="col-md-5 col-sm-5 col-xs-12">
							<!-- <form class="search-form pull-left">
								<input onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="Search this site" type="text">
								<input type="submit" value="" />
							</form> -->
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12">
							<!-- <div class="logo logo1">
								<h1 class="hidden"> </h1>
								<a href="index.html"><img src="images/home/home4/logo.png" alt="" /></a>
							</div> -->
						</div>
						<div class="col-md-5 col-sm-5 col-xs-12">
							 
	<svg viewBox="0 0 960 300">
	<symbol id="s-text">
		<text text-anchor="left" x="50%" y="80%">FaPS  </text>
	</symbol>

	<g class = "g-ants">
		<use xlink:href="#s-text" class="text-copy"></use>
		<use xlink:href="#s-text" class="text-copy"></use>
		<use xlink:href="#s-text" class="text-copy"></use>
		<use xlink:href="#s-text" class="text-copy"></use>
		<use xlink:href="#s-text" class="text-copy"></use>
	</g>
</svg>

						    
						</div>
					</div>
				</div>
			</div>
			<!-- End Main Header -->
			<?php
	include("header.php");
	?>
			<!-- End Nav Header -->
		</div>
	</header>
	
<?php
include('../dbconnect.php');
$sql = "SELECT COUNT(reg_id) AS n1 FROM  login";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n1=$row['n1'];
$sql = "SELECT COUNT(reg_id) AS n2 FROM  login WHERE status = '1'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n2=$row['n2'];
$sql = "SELECT COUNT(id) AS n3 FROM product ";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n3=$row['n3'];
$sql = "SELECT COUNT(sale_id) AS n4 FROM  sales";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$n4=$row['n4'];


?>
	<!-- End Header -->
			<div class="container">
			<div class="statistic-box">
				<h2 class="title30 font-bold text-center border-bottom">DATA</h2>
				<div class="list-statistic">
					<div class="row">
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="item-rotate-number text-center text-uppercase font-bold">
								<div class="rotate-number numscroller style1"><?php echo $n1 ?></div>
								<h2 class="title14">Registered Users</h2>
							</div>                  
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="item-rotate-number text-center text-uppercase font-bold">
								<div class="rotate-number numscroller style2"><?php echo $n2 ?></div>
								<h2 class="title14 color">Aproved User</h2>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="item-rotate-number text-center text-uppercase font-bold">
								<div class="rotate-number numscroller style3"><?php echo $n3 ?></div>
								<h2 class="title14 color2">Total Product</h2>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="item-rotate-number text-center text-uppercase font-bold">
								<div class="rotate-number numscroller style1"><?php echo $n4 ?></div>
								<h2 class="title14"> Sold Product</h2>
							</div>
						</div>
					</div>
				</div>
			</div>s
	<section id="content">
		<div class="container">
		 
			<!-- End Content Top -->
			<div class="top-service4">
				<div class="row">
				<h2 class="title30 font-bold title-box1 text-uppercase text-center">Modules</h2>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
							
			  
							</div>
							 
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="add_officer.php"><img style="border-radius: 50%;" src="image/icon/kisspng-registered-user-computer-icons-login-edit-user-cliparts-5ab3ceb3632f44.3127158915217332994063.jpg" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="add_officer.php" class="black">Add Officer</a></h3>
								<p class="desc"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
							
			 
								<a href="addcatagory.php"><img style="border-radius: 50%;" src="image/icon/product.jpg"> </a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="addcatagory.php" class="black">Add catagory</a></h3>
								<p class="desc"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<!-- <div class="service-icon">
								<a href="#"><img style="border-radius: 50%;" src="image/icon/product.jpg" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="block.php" class="black"></a>Add Product</h3>
								<p class="desc"> </p>
							</div> -->
						</div>
					</div>
				</div>
			</div>
				<div class="top-service4">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="products.php"><img style="border-radius: 50%;" src="image/icon/images (2).png" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="products.php" class="black">Product</a></h3>
								<p class="desc"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="notificationedit.php"><img style="border-radius: 50%;" src="image/icon/noti.png" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="notificationedit.php" class="black">notifications</a></h3>
								<!-- <h3 class="title18"><a href="sales.php" class="black">Sales Report</a></h3> -->
								<p class="desc"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<div class="item-service1 table">
							<div class="service-icon">
								<a href="#"><img style="border-radius: 50%;" src="image/icon/email-512.png" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="messages.php" class="black">feedbaCKS</a></h3>
								<p class="desc"> </p>
							</div>
						</div>
					</div>
				</div>
			</div>s
			<!-- End List Service -->
	 
	 
			<!-- End Product Type -->
 
			<!-- End Product Best Sale -->
			 
				<h2 class="title30 font-bold title-box1 text-uppercase text-center"> Users</h2>
			 
			<!-- End Latest News -->
			<div class="list-product-type4">
				<div class="row">
				 
 
				</div>
			</div>
			<!-- End Product Type -->
			<div class="list-service4">
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-6">
						<div class="item-service4 text-center">
							<div class="service-icon">
								 
							</div>
							 
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6">
						<div class="item-service4 text-center">
							<div class="service-icon">
								<a href="shopkeepers.php" class="white" style="background:#ff7979"> <img style="border-radius: 50%;" src="image/icon/dd.png" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="shopkeepers.php" class="black">Shopkeepers</a></h3>
								<p class="desc silver">  </p>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6">
						<div class="item-service4 text-center">
						<div class="service-icon">
								<a href="farmers.php" class="white" style="background:#66cc33"><img style="border-radius: 50%;" src="image/icon/wheat-farmer-icon-vector-19815131.jpg" ></a>
							</div>
							<div class="service-info">
								<h3 class="title18"><a href="farmers.php" class="black">Farmers</a></h3>
								<p class="desc silver"> </p>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6">


					.-
						 
					</div>
				</div>
			</div>
			<!-- End Service -->
	 
	 
		<div class="list-brand">
			<div class="container">
				<div class="brand-slider">
					<div class="wrap-item" data-pagination="false" data-autoplay="true" data-itemscustom="[[0,2],[480,3],[768,4],[990,5]]">
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br1.png" alt="" /></a>
						</div>
					
					 	<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br2.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br3.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br4.png" alt="" /></a>
						</div>
						<div class="item-brand">
							<a href="#" class="pulse-grow"><img src="images/home/home1/br5.png" alt="" /></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	 
	<!-- End Wishlist Mask -->
	<a href="#" class="scroll-top round"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_four"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_one"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
</div>
<script type="text/javascript" src="js/libs/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/libs/bootstrap.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/libs/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/libs/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.jcarousellite.min.js"></script>
<script type="text/javascript" src="js/libs/jquery.elevatezoom.js"></script>
<script type="text/javascript" src="js/libs/jqu20ery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/libs/slick.js"></script>
<script type="text/javascript" src="js/libs/popup.js"></script>
<script type="text/javascript" src="js/libs/timecircles.js"></script>
<script type="text/javascript" src="js/libs/wow.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
</body>
<?php

}
else
{
    header("location:../login.php");
}

?>
</html> 